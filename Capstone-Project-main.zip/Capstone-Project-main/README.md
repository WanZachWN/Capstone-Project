# Capstone-Project
ECE Capstone Project

To use the code, make sure you have OpenCV and darknet network.

Darknet options:

git clone https://github.com/AlexeyAB/darknet

git clone https://github.com/pjreddie/darknet.git
